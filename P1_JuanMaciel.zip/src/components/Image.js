import React from 'react';
import faker from 'faker';

function Image(props){
    return(
    <img src={props.source}/>
    )
}

export default Image;