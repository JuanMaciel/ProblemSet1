import React from 'react';
import faker from 'faker';

function Description(props){
    return(
        props.job
    )

}

export default Description;