import React from 'react';

function NumberOfFriends(props){
    return(
        props.number
    )
}

export default NumberOfFriends;