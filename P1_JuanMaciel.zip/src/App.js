import React from 'react';
import logo from './logo.svg';
import './App.css';
import faker from 'faker';
import Card from './components/Card';

function App() {
  return (
    <div className="App">
      
      <Card></Card>
      <Card></Card>
      <Card></Card>

      
    </div>
  );
}

export default App;
